//
//  ViewController.swift
//  CollectionViewMovieApp
//
//  Created by Madabhushi,Nikitha Vedant on 4/20/23.
//

import UIKit

class ViewController: UIViewController, UICollectionViewDataSource , UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return movies.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionViewOL.dequeueReusableCell(withReuseIdentifier: "movie", for: indexPath)
        as! MovieCollectionViewCell
        cell.assignMovies( movie : movies[indexPath.row])
            return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        assignMoviesDetails(index:indexPath)
    }
    func assignMoviesDetails(index:IndexPath){
        titleOL.text = "Movie title:\(movies[index.row].title)"
    }
    
    
    @IBOutlet weak var titleOL: UILabel!
    
    
    @IBOutlet weak var yearReleasedOL: UILabel!
    
    
    @IBOutlet weak var ratingOL: UILabel!
    
    
    @IBOutlet weak var boxOfficeOL: UILabel!
    
    
    @IBOutlet weak var collectionViewOL: UICollectionView!
    
    //create a cell
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        collectionViewOL.delegate = self
        collectionViewOL.dataSource = self
    }


}

