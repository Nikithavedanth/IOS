//
//  MovieCollectionViewCell.swift
//  CollectionViewMovieApp
//
//  Created by Madabhushi,Nikitha Vedant on 4/20/23.
//

import UIKit

class MovieCollectionViewCell: UICollectionViewCell {
    
    
    @IBOutlet weak var imageViewOL: UIImageView!
    //Assign movies into the cell, after creating the number of cells dynamically.
    func assignMovies(movie:movie){
    imageViewOL.image = movie.image
    
}
}
