import UIKit

var greeting = "Hello, playground"
var marks = 45
if marks>50 {
    print("The student has passed with \(marks) marks")}
else{
    print("The student had managed to get \(marks) marks")}

var inputNumber = -10
if inputNumber>0
{
    print("\(inputNumber) is a positive number")
}
else if( inputNumber<0){
    print("\(inputNumber) is a negative number")
}
else{
    print("the number is 0");
}

   
var stars = 65
if(stars>=90) {
    print("You are a Pro Member")
}
else if (stars>=78 && stars<90){
print("You are a Gold Member")
}
else if (stars>=65 && stars<78) {
    print("You are a VIP Member")
}
else {
    print("Default Plan")
}

