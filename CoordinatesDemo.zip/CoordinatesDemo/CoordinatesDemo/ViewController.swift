//
//  ViewController.swift
//  CoordinatesDemo
//
//  Created by Madabhushi,Nikitha Vedant on 3/23/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imageViewOutlet: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        let minX = imageViewOutlet.frame.minX
        let midX = imageViewOutlet.frame.midX
        let minY = imageViewOutlet.frame.minY
        let midY = imageViewOutlet.frame.midY
        print("(\(minX),\(minY))")
        let maxX = imageViewOutlet.frame.maxX
        let maxY = imageViewOutlet.frame.maxY
        print("(\(maxX),\(maxY))")
        print("(\(midX),\(midY))")
        //move the image view to the upper left corner of the screen/view
        imageViewOutlet.frame.origin.x = 0
        imageViewOutlet.frame.origin.y = 0
        //move the image view to the upper right corner of the screen/view
        imageViewOutlet.frame.origin.x = 314
        imageViewOutlet.frame.origin.y = 0
        //move the image view to the bottom left corner
        imageViewOutlet.frame.origin.x = 0
        imageViewOutlet.frame.origin.y = 796
        //move the image view to the bottom right corner
        imageViewOutlet.frame.origin.x = 314
        imageViewOutlet.frame.origin.y = 796
        //move the image view to the center of the screen x=(414/2-50)
        imageViewOutlet.frame.origin.x = 207-50
        imageViewOutlet.frame.origin.y = 448-50

}

}
