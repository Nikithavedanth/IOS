//
//  ViewController.swift
//  DiscountMVCApp
//
//  Created by Madabhushi,Nikitha Vedant on 3/30/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var amountOutlet: UITextField!
    
    @IBOutlet weak var discRateOutlet: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    var priceAfterDiscount = 0.0
    @IBAction func calcBtnClicked(_ sender: Any) {
        //Read the text and convert it into double value
        var amount = Double(amountOutlet.text!)
        print(amount!)
        var discRate = Double(discRateOutlet.text!)
        print(discRate!)
       
        priceAfterDiscount = amount!-(amount!*discRate!/100)
        print(priceAfterDiscount)
        
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        //create a transition
        var transition = segue.identifier
        //create destination
        if(transition == "resultSegue"){
            //reach the destination
            var destination = segue.destination
            as! ResultViewController
            destination.destinationAmount = amountOutlet.text!
            destination.destinationDiscRate = discRateOutlet.text!
            destination.destinationResult = String(priceAfterDiscount)
        }
        
    }
    
}

