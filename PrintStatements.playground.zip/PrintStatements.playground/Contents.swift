import UIKit

var greeting = "Hello, playground"
var i=10

print("Hii",10,12.25)

//String Interpolation
//everything with the quotation,variable
//naem with \(varName)
var name="Nikitha"
print("Hello,\(name)")
print("Hello,\(name)!")
print("Hello,"+name+"!")
print("Hello,\(name)! \(i)")
//print("Hello,"+name+"!"+i")

//print statement using String Interpolation
var programmingLANGUAGE = "swift"
print("My favourite programming language is \(programmingLANGUAGE)")

var age = 23
print("you are \(age) years old and in another \(age) years, you will be\(age * 2)")
print(age+1)
age = age-10
print(age)

print("""
Hello World! This is my first visit to maryville for my masters🤣
""")

var x=25
print("you are \(x) years old !")

print("Hello All,\rWelcome to Swift Programming😜")

// same as UML in java we declare variables with variable types
let welcomeMessage:String="Hello!"
print(welcomeMessage, "All🤪")//with comma in place it reads as space while printing
let k=10;
//k = k+1; k value cannot be changed as it is a constant.


//Usually a print statement is terminated by a new line
//To separate the print statements other than new line
//we can use it as follows
print("Welcome to swift programming")
print("Fall 2022")
print("***************")
print("Welcome to swift programming", terminator:"-")
print("Fall 2022")
//In general, the items in a print statement are separated by spaces, to print the //items separated by something other than spaces, we use separator
print("The list of numbers are")
print(1,2,3,4,5,6)
print("The new pattern is")
print(1,2,3,4,5,6,separator:"-")
