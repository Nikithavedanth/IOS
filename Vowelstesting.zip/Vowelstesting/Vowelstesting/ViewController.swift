//
//  ViewController.swift
//  Vowelstesting
//
//  Created by Madabhushi,Nikitha Vedant on 1/31/23.
//

import UIKit

class ViewController: UIViewController {

    
    
    @IBOutlet weak var textOutlet: UITextField!
    
    
    
    @IBOutlet weak var Labeloutlet: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
     }

    @IBAction func submitOutlet(_ sender: Any) {
        var text:String = textOutlet.text!
        
        if( text.contains("a")||text.contains("A")){
            Labeloutlet.text!="The entered \(text) contains vowels 😁"}
        else if( text.contains("e")||text.contains("E")){
            Labeloutlet.text!="The entered \(text) contains vowels 😁"}
        else if( text.contains("i")||text.contains("I")){
            Labeloutlet.text!="The entered \(text) contains vowels 😁"}
        else if( text.contains("o")||text.contains("O")){
            Labeloutlet.text!="The entered \(text) contains vowels 😁"}
        else if( text.contains("u")||text.contains("U")){
            Labeloutlet.text!="The entered \(text) contains vowels 😁"}
        else {
            Labeloutlet.text!="The entered \(text) does not contain vowels 😩"}
            
    }
}
        

