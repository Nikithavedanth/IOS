import UIKit
var greeting = "Hello, playground"
var httpError  = (errorCode : 404  , errorMessage : "Page Not Found")
print(httpError)
print(httpError.errorCode , terminator : ": ")
print(httpError.errorMessage )


var name = ("John","Smith")
var fName = name.0
var lName = name.1
print(fName , terminator : ",")
print(lName)

var origin = (x:0,y:0)
var point = origin
print("(",origin.x,",",origin.y,")" ,separator:"")


let city=(name:"Maryville",population:11,000)
let (cityName,cityPopulation)=(city.0,city.1)
print(cityName)
print(cityPopulation)

let groceries = ("bread","onions",10,20,40.00)
print(groceries.0)
print(groceries.1)
print(type(of:groceries))

var fname = "Joe"
var lname = "root"
(fname,lname)=(lname,fname)
print("First Name is \(fname) and last Name is \(lname)")

var cricketKit = ("handgloves","helmet",("bat","ball"))
print(cricketKit.0)
print(cricketKit.1)
print(cricketKit.2.0)
print(cricketKit.2.1)


var finame="Nikitha"
var laname="Madabhushi"
(finame,laname)=(laname,finame)
print("first name is \(finame) and my last name is \(laname) ")
