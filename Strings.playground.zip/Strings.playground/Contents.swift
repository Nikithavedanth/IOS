import UIKit
//String 01 worksheet

var greeting = "Hello, playground"
var fact = "Swift is a type safe language"
var dev = "Development of Swift began in 2010"
var author = "Swift was created by Chris Lattner"
fact.count
fact += ", it has a better memory management"
dev.append(" by Apple")
author.lowercased()
author.uppercased()
author[author.startIndex]
//author[author.endIndex]
author[author.index(before: author.endIndex)]
dev[dev.startIndex]//always use an array methodology to implement string in swift
dev[dev.index(before: dev.endIndex)]
author[author.index(after: author.startIndex)]
author[author.index(author.startIndex,offsetBy: 5)]
author[author.index(author.startIndex,offsetBy:8)]
dev[dev.index(after:dev.startIndex)]
author[author.index(author.endIndex,offsetBy: -5)]
author[author.index(author.endIndex,offsetBy:-10)]
fact[fact.index(fact.endIndex,offsetBy: -4)]
fact.count
author[author.index(after:author.startIndex)]

//String 02 worksheet

var shoppingList = "The shopping list contains: "
var foodItems = "Cheese, Butter, Chocolate Spread"
var clothes = "Socks, T-shirts"

if clothes.hasPrefix("Socks"){
    print("The first item in the clothes is socks");
}
    else{
        print("socks are not the first item in clothes")
    
}
print(foodItems.split(separator: ","))
if clothes.contains(",") {
print("Clothes contains more than one item")
}else{
   print("Clothes contain only one item")
}
foodItems[foodItems.startIndex..<foodItems.index(foodItems.endIndex,offsetBy:-7)]

shoppingList +=
foodItems[foodItems.index(foodItems.startIndex, offsetBy:
8)..<foodItems.endIndex]
print(shoppingList)

clothes.remove(at:clothes.firstIndex(of:"T")!)
print(clothes)

clothes.remove(at: clothes.firstIndex(of: "-")!)
print(clothes)
print("\(shoppingList), \(clothes)")
clothes.insert(contentsOf: ", Trousers", at:
clothes.endIndex)
var firstIndexOfR = shoppingList.index(after:shoppingList.firstIndex(of:"r")!)
print(shoppingList[..<firstIndexOfR])
