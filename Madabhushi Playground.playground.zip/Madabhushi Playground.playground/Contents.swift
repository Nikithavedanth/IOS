import UIKit

var greeting = "Hello, playground"
print(greeting)
var x=10.0
print(x)
var y=15
print(y)
var z=16.00000
print(z)
var t=3
print(t)
let u=[10,20,30,40]
print(u[0])
print(u[1])
print(u[1]+u[0])
var c="string"
var p="concatenation"
print(c+p)
