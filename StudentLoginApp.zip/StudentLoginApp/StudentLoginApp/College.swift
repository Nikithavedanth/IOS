//
//  College.swift
//  StudentLoginApp
//
//  Created by Madabhushi,Nikitha Vedant on 4/6/23.
//

import Foundation
