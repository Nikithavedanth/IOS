//
//  CourseInfoViewController.swift
//  StudentLoginApp
//
//  Created by Madabhushi,Nikitha Vedant on 4/4/23.
//

import UIKit

class CourseInfoViewController: UIViewController {
    
    @IBOutlet weak var crs1Outlet: UILabel!
    var coursesArray:[Course] = []
       override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
//           for course in coursesArray {
//                       crs1Outlet.text = crs1Outlet.text! + course.title + " - " + course.sem + "\n"
//
//                   }
           
           crs1Outlet.text = crs1Outlet.text! + coursesArray[0].title + "-" + coursesArray[0].sem + "\n"
           crs1Outlet.text = crs1Outlet.text! + coursesArray[1].title + "-" + coursesArray[1].sem + "\n"
           crs1Outlet.text = crs1Outlet.text! + coursesArray[2].title + "-" + coursesArray[2].sem + "\n"
           
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
