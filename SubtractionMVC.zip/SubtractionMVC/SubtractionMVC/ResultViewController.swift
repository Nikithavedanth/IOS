//
//  ResultViewController.swift
//  SubtractionMVC
//
//  Created by Kunuguntla,Indu Sri on 4/3/23.
//

import UIKit

class ResultViewController: UIViewController {

    @IBOutlet weak var num1: UILabel!
    
    
    
    @IBOutlet weak var num2: UILabel!
    
    
    
    @IBOutlet weak var result: UILabel!
    
    var n1 = ""
    var n2 = ""
    var r = ""
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        num1.text = num1.text! + n1
        num2.text = num2.text! + n2
        result.text = result.text!  + r

    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
