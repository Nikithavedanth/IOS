//
//  ViewController.swift
//  SubtractionMVC
//
//  Created by Kunuguntla,Indu Sri on 4/3/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var FirstNum: UITextField!
    
    
    @IBOutlet weak var SecondNum: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    var z = 0.0
    
    @IBAction func SubtractBTN(_ sender: UIButton) {
        
        var x = Double(FirstNum.text!)
        var y  = Double(SecondNum.text!)
        z = x! - y!
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var transition = segue.identifier
        
        if (transition == "ResultSegue")
        {
            var destination = segue.destination
            as!
            ResultViewController
            destination.n1 = FirstNum.text!
            destination.n2 = SecondNum.text!
            destination.r = String (z)
            FirstNum.text = ""
            SecondNum.text = ""
            
        }
    }
    
}
