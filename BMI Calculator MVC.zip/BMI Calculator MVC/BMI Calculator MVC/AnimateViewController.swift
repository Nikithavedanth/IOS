//
//  AnimateViewController.swift
//  BMI Calculator MVC
//
//  Created by Madabhushi,Nikitha Vedant on 4/9/23.
//

import UIKit

class AnimateViewController: UIViewController {
    
    var img1 = ""
    @IBOutlet weak var AnimateImageOutlet: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        AnimateImageOutlet.image = UIImage(named:img1)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
