import UIKit
var greeting = "Hello, playground"

var firstNumber:Int = 10
var secondNumber:Int = 25
print(secondNumber / firstNumber)

var four = 4
var finalNumber = -four
print(finalNumber)

var fn = 23
var ln = 2
print( fn/ln )

var number1 = (3,4)
var number2 = (4,5)
print(number1<number2)

var n1 = (4,5)
var n2 = (4,6)
print(n1<n2)


var n3 = (4,5)
var n4 = (4,5)
print(n3==n4)


var m = (3,6)
var s = (4,4)
print(m<s)

var five = 10
var finak = -five
print(finak)
